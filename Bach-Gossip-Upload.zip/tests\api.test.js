const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const request = require('supertest');
const sharp = require('sharp');

const { createApp } = require('../server');

test('creates and answers anonymous questions', async () => {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'anon-questions-'));
  const storagePath = path.join(tempDir, 'questions.json');
  const app = createApp(storagePath);

  const health = await request(app).get('/health');
  assert.equal(health.status, 200);
  assert.equal(health.body.status, 'ok');

  const privacyPage = await request(app).get('/datenschutz.html');
  assert.equal(privacyPage.status, 200);
  assert.match(privacyPage.text, /DATENSCHUTZ, wird bei uns großgeschrieben\./);
  assert.match(privacyPage.text, /Bestehen einer automatisierten Entscheidungsfindung/);

  const imprintPage = await request(app).get('/impressum.html');
  assert.equal(imprintPage.status, 200);
  assert.match(imprintPage.text, /<h1>Impressum<\/h1>/);
  assert.match(imprintPage.text, /Zuständige Aufsichtsbehörde/);

  const contactPage = await request(app).get('/kontakt.html');
  assert.equal(contactPage.status, 200);
  assert.match(contactPage.text, /<h1>Kontakt<\/h1>/);
  assert.match(contactPage.text, /Schüleranmeldung/);
  assert.match(contactPage.text, /RB 38827/);

  const postQuestion = await request(app)
    .post('/api/questions')
    .send({ text: 'Is this site anonymous?' });

  assert.equal(postQuestion.status, 201);
  assert.match(postQuestion.body.text, /Is this site anonymous\?/);

  const questionId = postQuestion.body.id;

  const answerResponse = await request(app)
    .post(`/api/questions/${questionId}/answers`)
    .send({ text: 'Yes, every post is anonymous by default.' });

  assert.equal(answerResponse.status, 201);
  assert.equal(answerResponse.body.text, 'Yes, every post is anonymous by default.');

  const fetchResponse = await request(app).get('/api/questions');
  assert.equal(fetchResponse.status, 200);
  assert.equal(fetchResponse.body[0].answers.length, 1);
  assert.equal(fetchResponse.body[0].answers[0].text, 'Yes, every post is anonymous by default.');
});

test('registers an account and only displays its username when requested', async () => {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'anon-accounts-'));
  const storagePath = path.join(tempDir, 'questions.json');
  const agent = request.agent(createApp(storagePath));

  const registration = await agent.post('/api/register').send({
    firstName: 'Johann',
    lastName: 'Bach',
    username: 'bachfan',
    password: 'secure-password-123',
    grade: 'KS1',
  });

  assert.equal(registration.status, 201);
  assert.equal(registration.body.username, 'bachfan');
  assert.equal(registration.body.grade, 'KS1');
  assert.equal(registration.body.password, undefined);

  const anonymousQuestion = await agent.post('/api/questions').send({
    text: 'Eine Frage ohne Namen',
    displayUsername: false,
  });
  assert.equal(anonymousQuestion.status, 201);
  assert.equal(anonymousQuestion.body.author, null);

  const namedQuestion = await agent.post('/api/questions').send({
    text: 'Eine Frage mit Username',
    displayUsername: true,
  });
  assert.equal(namedQuestion.status, 201);
  assert.equal(namedQuestion.body.author.username, 'bachfan');

  const answer = await agent.post(`/api/questions/${namedQuestion.body.id}/answers`).send({
    text: 'Eine Antwort mit Username',
    displayUsername: true,
  });
  assert.equal(answer.status, 201);
  assert.equal(answer.body.author.username, 'bachfan');
});

test('logs out and back in without storing the raw password', async () => {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'anon-login-'));
  const storagePath = path.join(tempDir, 'questions.json');
  const agent = request.agent(createApp(storagePath));
  const password = 'another-secure-password';

  await agent.post('/api/register').send({
    firstName: 'Anna',
    lastName: 'Muster',
    username: 'anna_test',
    password,
    grade: '8',
  }).expect(201);

  const storedAccounts = fs.readFileSync(`${storagePath}.accounts`, 'utf8');
  assert.equal(storedAccounts.includes(password), false);

  await agent.post('/api/logout').expect(204);
  assert.equal((await agent.get('/api/me')).body, null);

  const login = await agent.post('/api/login').send({ username: 'anna_test', password });
  assert.equal(login.status, 200);
  assert.equal(login.body.username, 'anna_test');
  assert.equal((await agent.get('/api/me')).body.username, 'anna_test');
});

test('supports anonymous confessions, rank assignment, gender privacy, and discussion replies', async () => {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jsb-discussion-'));
  const storagePath = path.join(tempDir, 'questions.json');
  const agent = request.agent(createApp(storagePath));

  const registration = await agent.post('/api/register').send({
    firstName: 'Lena',
    lastName: 'Beispiel',
    username: 'lena_klasse8',
    password: 'a-secure-password-888',
    grade: '8',
    gender: 'female',
  });
  assert.equal(registration.status, 201);
  assert.equal(registration.body.rank, 'Prospect');
  assert.equal(registration.body.gender, undefined);

  const question = await agent.post('/api/questions').send({
    text: 'Wie war euer Tag?',
    type: 'question',
    displayUsername: true,
    displayRank: true,
    genderVisibility: 'pixelated',
  });
  assert.equal(question.status, 201);
  assert.equal(question.body.author.username, 'lena_klasse8');
  assert.equal(question.body.author.gender, 'pixelated');
  assert.equal(question.body.author.rank, 'Prospect');

  const answer = await agent.post(`/api/questions/${question.body.id}/answers`).send({
    text: 'Ganz gut, danke!',
    displayUsername: true,
    displayRank: true,
  });
  assert.equal(answer.status, 201);
  assert.equal(answer.body.author.rank, 'Prospect');

  const reply = await agent.post(`/api/questions/${question.body.id}/answers/${answer.body.id}/replies`).send({
    text: 'Das freut mich!',
  });
  assert.equal(reply.status, 201);
  assert.equal(reply.body.text, 'Das freut mich!');

  const confession = await agent.post('/api/questions').send({
    text: 'Ich habe heute mein Pausenbrot vergessen.',
    type: 'confession',
    displayUsername: true,
    genderVisibility: 'public',
  });
  assert.equal(confession.status, 201);
  assert.equal(confession.body.type, 'confession');
  assert.equal(confession.body.author, null);

  const confessionAnswer = await agent.post(`/api/questions/${confession.body.id}/answers`).send({
    text: 'Danke fürs Teilen.',
    displayUsername: true,
    genderVisibility: 'public',
  });
  assert.equal(confessionAnswer.status, 201);
  assert.equal(confessionAnswer.body.author, null);

  const worry = await agent.post('/api/questions').send({
    text: 'Ich mache mir Sorgen wegen der nächsten Prüfung.',
    type: 'worry',
    displayUsername: true,
    genderVisibility: 'public',
  });
  assert.equal(worry.status, 201);
  assert.equal(worry.body.type, 'worry');
  assert.equal(worry.body.author, null);

  const worryAnswer = await agent.post(`/api/questions/${worry.body.id}/answers`).send({
    text: 'Du schaffst das!',
    displayUsername: true,
    genderVisibility: 'public',
  });
  assert.equal(worryAnswer.status, 201);
  assert.equal(worryAnswer.body.author, null);

  const wishlist = await agent.post('/api/questions').send({
    text: 'Mehr Sitzplätze im Pausenhof',
    type: 'wishlist',
    displayUsername: true,
    displayRank: true,
    genderVisibility: 'public',
  });
  assert.equal(wishlist.status, 201);
  assert.equal(wishlist.body.type, 'wishlist');
  assert.equal(wishlist.body.author.username, 'lena_klasse8');
  assert.equal(wishlist.body.author.gender, 'w');
  assert.equal(wishlist.body.author.rank, 'Prospect');

  const feed = await agent.get('/api/questions');
  const savedQuestion = feed.body.find((entry) => entry.id === question.body.id);
  assert.equal(savedQuestion.answers[0].replies[0].text, 'Das freut mich!');
});

test('uploads JPEG memes, supports reactions and comments, and keeps poll results hidden until a vote', async () => {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jsb-media-'));
  const storagePath = path.join(tempDir, 'questions.json');
  const agent = request.agent(createApp(storagePath));
  await agent.post('/api/register').send({
    firstName: 'Mia',
    lastName: 'Beispiel',
    username: 'meme_mia',
    password: 'secure-password-345',
    grade: '9',
    gender: 'female',
  }).expect(201);

  const jpeg = await sharp({
    create: { width: 24, height: 24, channels: 3, background: '#3f7657' },
  }).jpeg().toBuffer();
  const memeResponse = await agent.post('/api/memes')
    .attach('image', jpeg, { filename: 'school.jpg', contentType: 'image/jpeg' })
    .field('caption', 'Wenn die Pausenglocke endlich läutet')
    .field('displayUsername', 'true')
    .field('displayRank', 'true')
    .expect(201);

  assert.equal(memeResponse.body.author.username, 'meme_mia');
  assert.equal(memeResponse.body.author.rank, 'Challenger');
  assert.match(memeResponse.body.imageUrl, /^\/uploads\/[a-f0-9-]+\.jpg$/);
  const memeFile = path.join(tempDir, 'uploads', path.basename(memeResponse.body.imageUrl));
  assert.equal((await sharp(memeFile).metadata()).format, 'jpeg');

  await agent.post(`/api/memes/${memeResponse.body.id}/votes`).send({ reaction: 'like' }).expect(200);
  await agent.post(`/api/memes/${memeResponse.body.id}/comments`).send({ text: 'Klassiker!' }).expect(201);
  const memes = await agent.get('/api/memes').expect(200);
  assert.equal(memes.body[0].likes, 1);
  assert.equal(memes.body[0].comments[0].text, 'Klassiker!');

  const pollResponse = await agent.post('/api/polls').send({
    title: 'Welche Pause ist die beste?',
    options: ['Große Pause', 'Mittagspause', 'Freistunde'],
  }).expect(201);
  assert.equal(pollResponse.body.options.length, 3);

  const beforeVote = await agent.get('/api/polls').expect(200);
  assert.equal(beforeVote.body[0].results, undefined);
  assert.equal(beforeVote.body[0].options[0].votes, undefined);

  await agent.post(`/api/polls/${pollResponse.body.id}/votes`)
    .send({ optionId: pollResponse.body.options[1].id })
    .expect(200);
  const afterVote = await agent.get('/api/polls').expect(200);
  assert.equal(afterVote.body[0].results.totalVotes, 1);
  assert.equal(afterVote.body[0].options[1].percentage, 100);
  await agent.post(`/api/polls/${pollResponse.body.id}/votes`)
    .send({ optionId: pollResponse.body.options[0].id })
    .expect(409);

  const storedMemesPath = path.join(tempDir, 'memes.json');
  const storedMemes = JSON.parse(fs.readFileSync(storedMemesPath, 'utf8'));
  storedMemes[0].dislikes = Array.from({ length: 99 }, (_, index) => `seed-${index}`);
  fs.writeFileSync(storedMemesPath, JSON.stringify(storedMemes));
  const finalDislike = await agent.post(`/api/memes/${memeResponse.body.id}/votes`)
    .send({ reaction: 'dislike' })
    .expect(200);
  assert.equal(finalDislike.body.deleted, true);
  assert.equal(fs.existsSync(memeFile), false);
});

test('allows only owners to delete posts and cascades child content; stores reasoned reports', async () => {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'jsb-moderation-'));
  const storagePath = path.join(tempDir, 'questions.json');
  const app = createApp(storagePath);
  const owner = request.agent(app);
  const reporter = request.agent(app);

  await owner.post('/api/register').send({
    firstName: 'Mara', lastName: 'Owner', username: 'mara_owner',
    password: 'secure-password-owner', grade: '10', gender: 'female',
  }).expect(201);
  await reporter.post('/api/register').send({
    firstName: 'Theo', lastName: 'Reporter', username: 'theo_reporter',
    password: 'secure-password-report', grade: '9', gender: 'male',
  }).expect(201);

  const question = await owner.post('/api/questions').send({ text: 'Eine löschbare Frage' }).expect(201);
  await owner.post(`/api/questions/${question.body.id}/answers`).send({ text: 'Antwort' }).expect(201);
  const publicQuestions = await reporter.get('/api/questions').expect(200);
  assert.equal(publicQuestions.body[0].ownerId, undefined);
  assert.equal(publicQuestions.body[0].canDelete, false);
  assert.equal((await owner.get('/api/questions')).body[0].canDelete, true);
  await reporter.delete(`/api/questions/${question.body.id}`).expect(403);

  await reporter.post('/api/reports').send({
    contentType: 'question',
    contentId: question.body.id,
    reason: 'harassment',
  }).expect(201);
  await reporter.post('/api/reports').send({
    contentType: 'question',
    contentId: question.body.id,
    reason: 'spam',
  }).expect(409);

  await owner.delete(`/api/questions/${question.body.id}`).expect(200);
  assert.equal((await owner.get('/api/questions')).body.length, 0);

  const guest = request.agent(createApp(path.join(tempDir, 'guest-questions.json')));
  const guestQuestion = await guest.post('/api/questions').send({ text: 'Anonymer Gastbeitrag' }).expect(201);
  assert.equal((await guest.get('/api/questions')).body[0].canDelete, true);
  await guest.delete(`/api/questions/${guestQuestion.body.id}`).expect(200);

  const memeImage = await sharp({
    create: { width: 12, height: 12, channels: 3, background: '#285b45' },
  }).jpeg().toBuffer();
  const meme = await owner.post('/api/memes')
    .attach('image', memeImage, { filename: 'cascade.jpg', contentType: 'image/jpeg' })
    .expect(201);
  await owner.post(`/api/memes/${meme.body.id}/comments`).send({ text: 'Kommentar' }).expect(201);
  await reporter.delete(`/api/memes/${meme.body.id}`).expect(403);
  const memeFile = path.join(tempDir, 'uploads', path.basename(meme.body.imageUrl));
  await owner.delete(`/api/memes/${meme.body.id}`).expect(200);
  assert.equal(fs.existsSync(memeFile), false);
  assert.equal((await owner.get('/api/memes')).body.length, 0);

  const poll = await owner.post('/api/polls').send({
    title: 'Poll zum Löschen', options: ['Ja', 'Nein'],
  }).expect(201);
  await reporter.post(`/api/polls/${poll.body.id}/votes`).send({ optionId: poll.body.options[0].id }).expect(200);
  await owner.delete(`/api/polls/${poll.body.id}`).expect(200);
  assert.equal((await owner.get('/api/polls')).body.length, 0);
});

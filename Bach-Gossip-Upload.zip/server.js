const express = require('express');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const multer = require('multer');
const sharp = require('sharp');
const cookieName = 'jsb_gossip_session';
const visitorCookieName = 'bach_gossip_visitor';
const grades = new Set(['5', '6', '7', '8', '9', '10', '11', 'KS1', 'KS2']);
const ranks = {
  5: 'Rookie',
  6: 'Newcomer',
  7: 'Rising Star',
  8: 'Prospect',
  9: 'Challenger',
  10: 'Contender',
  11: 'Warrior',
  KS1: 'Veteran',
  KS2: 'Titan',
};
const genderLabels = {
  male: 'm',
  female: 'w',
  undisclosed: 'X',
};
const genderVisibilities = new Set(['hidden', 'pixelated', 'public']);
const postTypes = new Set(['question', 'confession', 'worry', 'wishlist']);
const anonymousPostTypes = new Set(['confession', 'worry']);
const reportReasons = new Set(['spam', 'harassment', 'discrimination', 'inappropriate', 'privacy', 'other']);
const reportableTypes = new Set(['question', 'meme', 'poll']);
const uploadMeme = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, callback) => {
    const validType = file.mimetype === 'image/jpeg' && /\.jpe?g$/i.test(file.originalname);
    callback(validType ? null : new Error('Bitte lade ein JPEG- oder JPG-Bild hoch.'), validType);
  },
});

function ensureStorageFile(storagePath, initialValue = []) {
  fs.mkdirSync(path.dirname(storagePath), { recursive: true });

  if (!fs.existsSync(storagePath)) {
    fs.writeFileSync(storagePath, JSON.stringify(initialValue, null, 2));
  }
}

function loadJson(storagePath, initialValue = []) {
  ensureStorageFile(storagePath, initialValue);

  try {
    const raw = fs.readFileSync(storagePath, 'utf8');
    const parsed = JSON.parse(raw);
    return parsed;
  } catch {
    return initialValue;
  }
}

function saveJson(storagePath, value) {
  ensureStorageFile(storagePath);
  fs.writeFileSync(storagePath, JSON.stringify(value, null, 2));
}

function cleanText(value) {
  return typeof value === 'string' ? value.trim().replace(/\s+/g, ' ') : '';
}

function isEnabled(value) {
  return value === true || value === 'true' || value === '1' || value === 'on';
}

function parseCookies(header = '') {
  return Object.fromEntries(header.split(';').map((part) => {
    const separator = part.indexOf('=');
    return separator === -1
      ? ['', '']
      : [part.slice(0, separator).trim(), decodeURIComponent(part.slice(separator + 1).trim())];
  }).filter(([key]) => key));
}

function createApp(storagePath = path.join(__dirname, 'data', 'questions.json')) {
  const app = express();
  const accountsPath = `${storagePath}.accounts`;
  const secretPath = `${storagePath}.secret`;
  const dataDirectory = path.dirname(storagePath);
  const memesPath = path.join(dataDirectory, 'memes.json');
  const pollsPath = path.join(dataDirectory, 'polls.json');
  const reportsPath = path.join(dataDirectory, 'reports.json');
  const uploadDirectory = path.join(dataDirectory, 'uploads');
  ensureStorageFile(secretPath, crypto.randomBytes(48).toString('hex'));
  const sessionSecret = fs.readFileSync(secretPath, 'utf8');

  function getAccounts() {
    const accounts = loadJson(accountsPath, []);
    return Array.isArray(accounts) ? accounts : [];
  }

  function currentUser(req) {
    const token = parseCookies(req.headers.cookie)[cookieName];
    if (!token) return null;

    const [payload, signature] = token.split('.');
    if (!payload || !signature) return null;

    const expected = crypto.createHmac('sha256', sessionSecret).update(payload).digest('base64url');
    const expectedBuffer = Buffer.from(expected);
    const signatureBuffer = Buffer.from(signature);
    if (expectedBuffer.length !== signatureBuffer.length || !crypto.timingSafeEqual(expectedBuffer, signatureBuffer)) return null;

    try {
      const session = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
      if (session.expiresAt < Date.now()) return null;
      return getAccounts().find((account) => account.id === session.userId) || null;
    } catch {
      return null;
    }
  }

  function currentOwnerId(req, res, user = currentUser(req)) {
    if (user) return user.id;
    const token = parseCookies(req.headers.cookie)[visitorCookieName];
    const [visitorId, signature] = token?.split('.') || [];
    if (visitorId && signature && /^[a-f0-9-]{36}$/.test(visitorId)) {
      const expected = crypto.createHmac('sha256', sessionSecret).update(visitorId).digest('base64url');
      const expectedBuffer = Buffer.from(expected);
      const signatureBuffer = Buffer.from(signature);
      if (expectedBuffer.length === signatureBuffer.length && crypto.timingSafeEqual(expectedBuffer, signatureBuffer)) {
        return `visitor:${visitorId}`;
      }
    }

    const newVisitorId = crypto.randomUUID();
    const newSignature = crypto.createHmac('sha256', sessionSecret).update(newVisitorId).digest('base64url');
    res.cookie(visitorCookieName, `${newVisitorId}.${newSignature}`, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      maxAge: 365 * 24 * 60 * 60 * 1000,
      path: '/',
    });
    return `visitor:${newVisitorId}`;
  }

  function setSession(res, account) {
    const payload = Buffer.from(JSON.stringify({
      userId: account.id,
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
    })).toString('base64url');
    const signature = crypto.createHmac('sha256', sessionSecret).update(payload).digest('base64url');
    res.cookie(cookieName, `${payload}.${signature}`, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      maxAge: 7 * 24 * 60 * 60 * 1000,
      path: '/',
    });
  }

  function publicAccount(account) {
    return { username: account.username, grade: account.grade, rank: ranks[account.grade] };
  }

  function publicAuthor(account, displayUsername, displayRank, genderVisibility) {
    if (!account) return null;

    const author = {
      username: displayUsername ? account.username : null,
      rank: displayRank ? ranks[account.grade] : null,
      gender: genderVisibility === 'pixelated'
        ? 'pixelated'
        : genderVisibility === 'public'
          ? genderLabels[account.gender]
          : null,
    };
    return author.username || author.rank || author.gender ? author : null;
  }

  function authorFromRequest(req, account) {
    return publicAuthor(
      account,
      isEnabled(req.body?.displayUsername),
      isEnabled(req.body?.displayRank),
      genderVisibilities.has(req.body?.genderVisibility) ? req.body.genderVisibility : 'hidden',
    );
  }

  function getMemes() {
    const memes = loadJson(memesPath, []);
    return Array.isArray(memes) ? memes : [];
  }

  function publicQuestion(question, ownerId) {
    const { ownerId: storedOwnerId, ...publicData } = question;
    return {
      ...publicData,
      canDelete: Boolean(ownerId && storedOwnerId === ownerId),
    };
  }

  function publicMeme(meme, user, ownerId) {
    const likes = Array.isArray(meme.likes) ? meme.likes : [];
    const dislikes = Array.isArray(meme.dislikes) ? meme.dislikes : [];
    return {
      id: meme.id,
      caption: meme.caption,
      imageUrl: meme.imageUrl,
      createdAt: meme.createdAt,
      author: meme.author,
      canDelete: Boolean(ownerId && meme.ownerId === ownerId),
      likes: likes.length,
      dislikes: dislikes.length,
      userReaction: user
        ? likes.includes(user.id) ? 'like' : dislikes.includes(user.id) ? 'dislike' : null
        : null,
      comments: meme.comments || [],
    };
  }

  function getPolls() {
    const polls = loadJson(pollsPath, []);
    return Array.isArray(polls) ? polls : [];
  }

  function publicPoll(poll, user, ownerId) {
    const options = poll.options || [];
    const hasVoted = Boolean(user && (poll.votedUserIds || []).includes(user.id));
    if (!hasVoted) {
      return {
        id: poll.id,
        title: poll.title,
        options: options.map(({ id, text }) => ({ id, text })),
        createdAt: poll.createdAt,
        author: poll.author,
        canDelete: Boolean(ownerId && poll.ownerId === ownerId),
        hasVoted: false,
      };
    }

    const totalVotes = options.reduce((total, option) => total + option.voters.length, 0);
    return {
      id: poll.id,
      title: poll.title,
      options: options.map((option) => ({
        id: option.id,
        text: option.text,
        votes: option.voters.length,
        percentage: totalVotes ? Math.round(option.voters.length / totalVotes * 100) : 0,
      })),
      createdAt: poll.createdAt,
      author: poll.author,
      canDelete: Boolean(ownerId && poll.ownerId === ownerId),
      hasVoted: true,
      results: { totalVotes },
    };
  }

  app.use(express.json());
  app.get('/health', (req, res) => res.json({ status: 'ok' }));
  app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));
  app.get('/datenschutz.html', (req, res) => res.sendFile(path.join(__dirname, 'datenschutz.html')));
  app.get('/impressum.html', (req, res) => res.sendFile(path.join(__dirname, 'impressum.html')));
  app.get('/kontakt.html', (req, res) => res.sendFile(path.join(__dirname, 'kontakt.html')));
  app.get('/styles.css', (req, res) => res.sendFile(path.join(__dirname, 'styles.css')));
  app.get('/app.js', (req, res) => res.sendFile(path.join(__dirname, 'app.js')));
  app.get('/beaver-logo.svg', (req, res) => res.sendFile(path.join(__dirname, 'beaver-logo.svg')));

  app.get('/uploads/:filename', (req, res) => {
    if (!/^[a-f0-9-]{36}\.jpg$/.test(req.params.filename)) return res.sendStatus(404);
    return res.sendFile(path.join(uploadDirectory, req.params.filename), (error) => {
      if (error && !res.headersSent) res.sendStatus(404);
    });
  });

  app.post('/api/register', (req, res) => {
    const firstName = cleanText(req.body?.firstName);
    const lastName = cleanText(req.body?.lastName);
    const username = cleanText(req.body?.username);
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const grade = cleanText(req.body?.grade);
    const gender = cleanText(req.body?.gender) || 'undisclosed';

    if (firstName.length < 2 || firstName.length > 60 || lastName.length < 2 || lastName.length > 60) {
      return res.status(400).json({ error: 'Bitte gib einen gültigen Vor- und Nachnamen an.' });
    }
    if (!/^[a-zA-Z0-9_.-]{3,24}$/.test(username)) {
      return res.status(400).json({ error: 'Der Username muss 3 bis 24 Zeichen lang sein und darf Buchstaben, Zahlen, Punkt, _ oder - enthalten.' });
    }
    if (password.length < 10 || password.length > 128) {
      return res.status(400).json({ error: 'Das Passwort muss mindestens 10 Zeichen lang sein.' });
    }
    if (!grades.has(grade)) {
      return res.status(400).json({ error: 'Bitte wähle eine gültige Klasse von 5 bis KS2.' });
    }
    if (!Object.hasOwn(genderLabels, gender)) {
      return res.status(400).json({ error: 'Bitte wähle eine gültige Geschlechtsangabe.' });
    }

    const accounts = getAccounts();
    if (accounts.some((account) => account.username.toLowerCase() === username.toLowerCase())) {
      return res.status(409).json({ error: 'Dieser Username ist bereits vergeben.' });
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const account = {
      id: crypto.randomUUID(),
      firstName,
      lastName,
      username,
      grade,
      gender,
      salt,
      passwordHash: crypto.scryptSync(password, salt, 64).toString('hex'),
    };
    accounts.push(account);
    saveJson(accountsPath, accounts);
    setSession(res, account);
    return res.status(201).json(publicAccount(account));
  });

  app.post('/api/login', (req, res) => {
    const username = cleanText(req.body?.username);
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const account = getAccounts().find((entry) => entry.username.toLowerCase() === username.toLowerCase());

    if (!account || password.length > 128) {
      return res.status(401).json({ error: 'Username oder Passwort ist falsch.' });
    }
    const suppliedHash = crypto.scryptSync(password, account.salt, 64);
    const storedHash = Buffer.from(account.passwordHash, 'hex');
    if (suppliedHash.length !== storedHash.length || !crypto.timingSafeEqual(suppliedHash, storedHash)) {
      return res.status(401).json({ error: 'Username oder Passwort ist falsch.' });
    }

    setSession(res, account);
    return res.json(publicAccount(account));
  });

  app.post('/api/logout', (req, res) => {
    res.clearCookie(cookieName, { httpOnly: true, sameSite: 'lax', path: '/' });
    return res.sendStatus(204);
  });

  app.get('/api/me', (req, res) => {
    const account = currentUser(req);
    return res.json(account ? publicAccount(account) : null);
  });

  app.get('/api/questions', (req, res) => {
    const questions = loadJson(storagePath, []);
    const ownerId = currentOwnerId(req, res);
    res.json(questions.map((question) => publicQuestion(question, ownerId)));
  });

  app.post('/api/questions', (req, res) => {
    const text = cleanText(req.body?.text);
    const type = postTypes.has(req.body?.type) ? req.body.type : 'question';
    const genderVisibility = genderVisibilities.has(req.body?.genderVisibility)
      ? req.body.genderVisibility
      : 'hidden';

    if (!text) {
      return res.status(400).json({ error: 'Bitte gib einen Text ein.' });
    }

    const user = currentUser(req);
    const displayUsername = !anonymousPostTypes.has(type) && Boolean(req.body?.displayUsername);
    const displayRank = !anonymousPostTypes.has(type) && Boolean(req.body?.displayRank);
    const visibleGender = anonymousPostTypes.has(type) ? 'hidden' : genderVisibility;
    if ((displayUsername || displayRank || visibleGender !== 'hidden') && !user) {
      return res.status(401).json({ error: 'Bitte melde dich an, um Profildaten anzuzeigen.' });
    }

    const questions = loadJson(storagePath, []);
    const ownerId = currentOwnerId(req, res, user);
    const question = {
      id: crypto.randomUUID(),
      text,
      type,
      createdAt: new Date().toISOString(),
      author: anonymousPostTypes.has(type) ? null : publicAuthor(user, displayUsername, displayRank, visibleGender),
      ownerId,
      answers: [],
    };

    questions.unshift(question);
    saveJson(storagePath, questions);
    return res.status(201).json(publicQuestion(question, ownerId));
  });

  app.delete('/api/questions/:id', (req, res) => {
    const ownerId = currentOwnerId(req, res);
    const questions = loadJson(storagePath, []);
    const questionIndex = questions.findIndex((entry) => entry.id === req.params.id);
    if (questionIndex === -1) return res.status(404).json({ error: 'Beitrag nicht gefunden.' });
    if (!questions[questionIndex].ownerId || questions[questionIndex].ownerId !== ownerId) {
      return res.status(403).json({ error: 'Du kannst nur eigene Beiträge löschen.' });
    }
    questions.splice(questionIndex, 1);
    saveJson(storagePath, questions);
    return res.json({ deleted: true });
  });

  app.post('/api/questions/:id/answers', (req, res) => {
    const text = cleanText(req.body?.text);
    const genderVisibility = genderVisibilities.has(req.body?.genderVisibility)
      ? req.body.genderVisibility
      : 'hidden';

    if (!text) {
      return res.status(400).json({ error: 'Bitte gib eine Antwort ein.' });
    }

    const user = currentUser(req);
    const displayUsername = Boolean(req.body?.displayUsername);
    const displayRank = Boolean(req.body?.displayRank);
    if ((displayUsername || displayRank || genderVisibility !== 'hidden') && !user) {
      return res.status(401).json({ error: 'Bitte melde dich an, um Profildaten anzuzeigen.' });
    }

    const questions = loadJson(storagePath, []);
    const question = questions.find((entry) => entry.id === req.params.id);

    if (!question) {
      return res.status(404).json({ error: 'Question not found.' });
    }

    const answer = {
      id: crypto.randomUUID(),
      text,
      createdAt: new Date().toISOString(),
      author: anonymousPostTypes.has(question.type) ? null : publicAuthor(user, displayUsername, displayRank, genderVisibility),
      replies: [],
    };

    question.answers.push(answer);
    saveJson(storagePath, questions);
    return res.status(201).json(answer);
  });

  app.post('/api/questions/:questionId/answers/:answerId/replies', (req, res) => {
    const text = cleanText(req.body?.text);
    const genderVisibility = genderVisibilities.has(req.body?.genderVisibility)
      ? req.body.genderVisibility
      : 'hidden';
    if (!text) return res.status(400).json({ error: 'Bitte gib eine Antwort ein.' });

    const user = currentUser(req);
    const displayUsername = Boolean(req.body?.displayUsername);
    const displayRank = Boolean(req.body?.displayRank);
    if ((displayUsername || displayRank || genderVisibility !== 'hidden') && !user) {
      return res.status(401).json({ error: 'Bitte melde dich an, um Profildaten anzuzeigen.' });
    }

    const questions = loadJson(storagePath, []);
    const question = questions.find((entry) => entry.id === req.params.questionId);
    const answer = question?.answers.find((entry) => entry.id === req.params.answerId);
    if (!answer) return res.status(404).json({ error: 'Antwort nicht gefunden.' });

    answer.replies = Array.isArray(answer.replies) ? answer.replies : [];
    const reply = {
      id: crypto.randomUUID(),
      text,
      createdAt: new Date().toISOString(),
      author: anonymousPostTypes.has(question.type) ? null : publicAuthor(user, displayUsername, displayRank, genderVisibility),
    };
    answer.replies.push(reply);
    saveJson(storagePath, questions);
    return res.status(201).json(reply);
  });

  app.get('/api/memes', (req, res) => {
    const user = currentUser(req);
    const ownerId = currentOwnerId(req, res, user);
    return res.json(getMemes().map((meme) => publicMeme(meme, user, ownerId)));
  });

  app.post('/api/memes', (req, res, next) => {
    uploadMeme.single('image')(req, res, (error) => {
      if (error) {
        const status = error.code === 'LIMIT_FILE_SIZE' ? 413 : 400;
        return res.status(status).json({ error: error.message });
      }
      return next();
    });
  }, async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'Bitte wähle ein JPEG-Bild aus.' });
    const caption = cleanText(req.body?.caption);
    if (caption.length > 300) return res.status(400).json({ error: 'Die Bildunterschrift darf höchstens 300 Zeichen lang sein.' });

    const user = currentUser(req);
    const ownerId = currentOwnerId(req, res, user);
    const hasPublicDetails = isEnabled(req.body?.displayUsername)
      || isEnabled(req.body?.displayRank)
      || (req.body?.genderVisibility && req.body.genderVisibility !== 'hidden');
    if (hasPublicDetails && !user) {
      return res.status(401).json({ error: 'Bitte melde dich an, um Profildaten anzuzeigen.' });
    }

    let processedImage;
    try {
      const image = sharp(req.file.buffer, { limitInputPixels: 40000000 });
      const metadata = await image.metadata();
      if (metadata.format !== 'jpeg') return res.status(400).json({ error: 'Die Datei enthält kein gültiges JPEG-Bild.' });
      processedImage = await image.rotate()
        .resize({ width: 1920, height: 1920, fit: 'inside', withoutEnlargement: true })
        .jpeg({ quality: 88 })
        .toBuffer();
    } catch {
      return res.status(400).json({ error: 'Das JPEG-Bild konnte nicht gelesen werden.' });
    }

    fs.mkdirSync(uploadDirectory, { recursive: true });
    const id = crypto.randomUUID();
    const imageUrl = `/uploads/${id}.jpg`;
    fs.writeFileSync(path.join(uploadDirectory, `${id}.jpg`), processedImage);
    const meme = {
      id,
      caption,
      imageUrl,
      createdAt: new Date().toISOString(),
      author: authorFromRequest(req, user),
      ownerId,
      likes: [],
      dislikes: [],
      comments: [],
    };
    const memes = getMemes();
    memes.unshift(meme);
    saveJson(memesPath, memes);
    return res.status(201).json(publicMeme(meme, user, ownerId));
  });

  app.delete('/api/memes/:id', (req, res) => {
    const ownerId = currentOwnerId(req, res);
    const memes = getMemes();
    const memeIndex = memes.findIndex((entry) => entry.id === req.params.id);
    if (memeIndex === -1) return res.status(404).json({ error: 'Meme nicht gefunden.' });
    const meme = memes[memeIndex];
    if (!meme.ownerId || meme.ownerId !== ownerId) {
      return res.status(403).json({ error: 'Du kannst nur eigene Beiträge löschen.' });
    }
    memes.splice(memeIndex, 1);
    saveJson(memesPath, memes);
    fs.rmSync(path.join(uploadDirectory, path.basename(meme.imageUrl)), { force: true });
    return res.json({ deleted: true });
  });

  app.post('/api/memes/:id/votes', (req, res) => {
    const user = currentUser(req);
    if (!user) return res.status(401).json({ error: 'Bitte melde dich an, um Memes zu bewerten.' });
    const reaction = req.body?.reaction;
    if (!['like', 'dislike', 'remove'].includes(reaction)) {
      return res.status(400).json({ error: 'Ungültige Bewertung.' });
    }

    const memes = getMemes();
    const memeIndex = memes.findIndex((entry) => entry.id === req.params.id);
    if (memeIndex === -1) return res.status(404).json({ error: 'Meme nicht gefunden.' });
    const meme = memes[memeIndex];
    meme.likes = (meme.likes || []).filter((id) => id !== user.id);
    meme.dislikes = (meme.dislikes || []).filter((id) => id !== user.id);
    if (reaction === 'like') meme.likes.push(user.id);
    if (reaction === 'dislike') meme.dislikes.push(user.id);

    if (meme.dislikes.length > 99) {
      memes.splice(memeIndex, 1);
      saveJson(memesPath, memes);
      fs.rmSync(path.join(uploadDirectory, path.basename(meme.imageUrl)), { force: true });
      return res.json({ deleted: true });
    }

    saveJson(memesPath, memes);
    return res.json(publicMeme(meme, user));
  });

  app.post('/api/memes/:id/comments', (req, res) => {
    const text = cleanText(req.body?.text);
    if (!text || text.length > 500) return res.status(400).json({ error: 'Der Kommentar muss 1 bis 500 Zeichen lang sein.' });
    const user = currentUser(req);
    const hasPublicDetails = isEnabled(req.body?.displayUsername)
      || isEnabled(req.body?.displayRank)
      || (req.body?.genderVisibility && req.body.genderVisibility !== 'hidden');
    if (hasPublicDetails && !user) {
      return res.status(401).json({ error: 'Bitte melde dich an, um Profildaten anzuzeigen.' });
    }

    const memes = getMemes();
    const meme = memes.find((entry) => entry.id === req.params.id);
    if (!meme) return res.status(404).json({ error: 'Meme nicht gefunden.' });
    meme.comments = Array.isArray(meme.comments) ? meme.comments : [];
    const comment = {
      id: crypto.randomUUID(),
      text,
      createdAt: new Date().toISOString(),
      author: authorFromRequest(req, user),
    };
    meme.comments.push(comment);
    saveJson(memesPath, memes);
    return res.status(201).json(comment);
  });

  app.get('/api/polls', (req, res) => {
    const user = currentUser(req);
    const ownerId = currentOwnerId(req, res, user);
    return res.json(getPolls().map((poll) => publicPoll(poll, user, ownerId)));
  });

  app.post('/api/polls', (req, res) => {
    const title = cleanText(req.body?.title);
    const options = Array.isArray(req.body?.options) ? req.body.options.map(cleanText) : [];
    if (title.length < 3 || title.length > 200) {
      return res.status(400).json({ error: 'Der Umfragetitel muss 3 bis 200 Zeichen lang sein.' });
    }
    if (options.length < 2 || options.length > 6 || options.some((option) => !option || option.length > 100)) {
      return res.status(400).json({ error: 'Eine Umfrage braucht 2 bis 6 gültige Antwortmöglichkeiten.' });
    }
    if (new Set(options.map((option) => option.toLocaleLowerCase('de'))).size !== options.length) {
      return res.status(400).json({ error: 'Antwortmöglichkeiten müssen unterschiedlich sein.' });
    }
    const user = currentUser(req);
    const hasPublicDetails = isEnabled(req.body?.displayUsername)
      || isEnabled(req.body?.displayRank)
      || (req.body?.genderVisibility && req.body.genderVisibility !== 'hidden');
    if (hasPublicDetails && !user) {
      return res.status(401).json({ error: 'Bitte melde dich an, um Profildaten anzuzeigen.' });
    }

    const poll = {
      id: crypto.randomUUID(),
      title,
      options: options.map((text) => ({ id: crypto.randomUUID(), text, voters: [] })),
      createdAt: new Date().toISOString(),
      author: authorFromRequest(req, user),
      ownerId: currentOwnerId(req, res, user),
      votedUserIds: [],
    };
    const polls = getPolls();
    polls.unshift(poll);
    saveJson(pollsPath, polls);
    return res.status(201).json(publicPoll(poll, user, poll.ownerId));
  });

  app.delete('/api/polls/:id', (req, res) => {
    const ownerId = currentOwnerId(req, res);
    const polls = getPolls();
    const pollIndex = polls.findIndex((entry) => entry.id === req.params.id);
    if (pollIndex === -1) return res.status(404).json({ error: 'Umfrage nicht gefunden.' });
    if (!polls[pollIndex].ownerId || polls[pollIndex].ownerId !== ownerId) {
      return res.status(403).json({ error: 'Du kannst nur eigene Beiträge löschen.' });
    }
    polls.splice(pollIndex, 1);
    saveJson(pollsPath, polls);
    return res.json({ deleted: true });
  });

  app.post('/api/polls/:id/votes', (req, res) => {
    const user = currentUser(req);
    if (!user) return res.status(401).json({ error: 'Bitte melde dich an, um abzustimmen.' });
    const polls = getPolls();
    const poll = polls.find((entry) => entry.id === req.params.id);
    if (!poll) return res.status(404).json({ error: 'Umfrage nicht gefunden.' });
    if ((poll.votedUserIds || []).includes(user.id)) {
      return res.status(409).json({ error: 'Du hast bei dieser Umfrage bereits abgestimmt.' });
    }
    const option = poll.options.find((entry) => entry.id === req.body?.optionId);
    if (!option) return res.status(400).json({ error: 'Bitte wähle eine gültige Antwortmöglichkeit.' });
    option.voters.push(user.id);
    poll.votedUserIds = [...(poll.votedUserIds || []), user.id];
    saveJson(pollsPath, polls);
    return res.json(publicPoll(poll, user));
  });

  app.post('/api/reports', (req, res) => {
    const user = currentUser(req);
    if (!user) return res.status(401).json({ error: 'Bitte melde dich an, um einen Beitrag zu melden.' });
    const contentType = req.body?.contentType;
    const contentId = cleanText(req.body?.contentId);
    const reason = req.body?.reason;
    if (!reportableTypes.has(contentType) || !contentId || !reportReasons.has(reason)) {
      return res.status(400).json({ error: 'Bitte wähle einen gültigen Meldegrund.' });
    }

    const collections = {
      question: loadJson(storagePath, []),
      meme: getMemes(),
      poll: getPolls(),
    };
    if (!collections[contentType].some((entry) => entry.id === contentId)) {
      return res.status(404).json({ error: 'Der Beitrag wurde nicht gefunden.' });
    }

    const reports = loadJson(reportsPath, []);
    if (reports.some((entry) => entry.reporterId === user.id
      && entry.contentType === contentType && entry.contentId === contentId)) {
      return res.status(409).json({ error: 'Du hast diesen Beitrag bereits gemeldet.' });
    }

    const report = {
      id: crypto.randomUUID(),
      contentType,
      contentId,
      reason,
      reporterId: user.id,
      createdAt: new Date().toISOString(),
    };
    reports.push(report);
    saveJson(reportsPath, reports);
    return res.status(201).json({ id: report.id, message: 'Danke. Deine Meldung wurde gespeichert.' });
  });

  return app;
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  const storagePath = path.join(__dirname, 'data', 'questions.json');
  const app = createApp(storagePath);

  app.listen(port, () => {
    console.log(`Anonymous Q&A app running at http://localhost:${port}`);
  });
}

module.exports = { createApp };

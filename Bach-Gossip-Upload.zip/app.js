const questionForm = document.getElementById('question-form');
const questionInput = document.getElementById('question-input');
const questionsContainer = document.getElementById('questions');
const questionCount = document.getElementById('question-count');
const questionTemplate = document.getElementById('question-template');
const accountDialog = document.getElementById('account-dialog');
const accountButton = document.getElementById('account-button');
const logoutButton = document.getElementById('logout-button');
const accountLabel = document.getElementById('account-label');
const notice = document.getElementById('notice');
const authError = document.getElementById('auth-error');
const searchInput = document.getElementById('search-input');
let currentAccount = null;
let allPosts = [];
let activeMode = 'question';
let activeStatus = 'all';
let activeSort = 'newest';
let pendingReport = null;
let pendingDelete = null;

function showNotice(message, isError = false) {
  notice.textContent = message;
  notice.classList.toggle('is-error', isError);
  notice.hidden = !message;
}

async function requestJson(url, options = {}) {
  const headers = { ...options.headers };
  if (!(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';
  const response = await fetch(url, {
    ...options,
    headers,
  });
  const data = response.status === 204 ? null : await response.json();
  if (!response.ok) throw new Error(data?.error || 'Das hat gerade nicht geklappt.');
  return data;
}

function updateAccountControls() {
  const identityControls = document.querySelectorAll('#question-form .identity-choice, .meme-identity-choice, .poll-identity-choice');
  identityControls.forEach((choice) => {
    const allowedMode = ['question', 'wishlist'].includes(activeMode)
      || (activeMode === 'memes' && choice.classList.contains('meme-identity-choice'))
      || (activeMode === 'polls' && choice.classList.contains('poll-identity-choice'));
    choice.hidden = !currentAccount || !allowedMode;
  });
  if (!currentAccount || !['question', 'wishlist', 'memes', 'polls'].includes(activeMode)) {
    document.querySelectorAll('#question-form .identity-choice input, .meme-identity-choice input, .poll-identity-choice input').forEach((input) => {
      if (input.type === 'checkbox') input.checked = false;
    });
    document.querySelectorAll('.identity-choice select').forEach((select) => {
      select.value = 'hidden';
    });
  }
  document.getElementById('guest-hint').hidden = Boolean(currentAccount) && activeMode === 'question';
  accountButton.hidden = Boolean(currentAccount);
  logoutButton.hidden = !currentAccount;
  accountLabel.hidden = !currentAccount;
  accountLabel.textContent = currentAccount
    ? `@${currentAccount.username} · ${currentAccount.rank}`
    : '';
}

async function loadQuestions() {
  try {
    allPosts = await requestJson('/api/questions');
    renderQuestions();
  } catch (error) {
    showNotice(error.message, true);
  }
}

async function reloadActiveMode() {
  if (activeMode === 'memes') return loadMemes();
  if (activeMode === 'polls') return loadPolls();
  return loadQuestions();
}

function formatTime(dateString) {
  return new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(new Date(dateString));
}

function popularity(post) {
  return (post.answers || []).reduce((total, answer) => total + 1 + (answer.replies || []).length, 0);
}

function discussionPopularity(answer) {
  return (answer.replies || []).length;
}

function sortItems(items) {
  return [...items].sort((left, right) => {
    if (activeSort === 'popular') {
      const scoreDifference = discussionPopularity(right) - discussionPopularity(left);
      if (scoreDifference) return scoreDifference;
    }
    const timeDifference = new Date(right.createdAt) - new Date(left.createdAt);
    return activeSort === 'oldest' ? -timeDifference : timeDifference;
  });
}

function postMatchesSearch(post, query) {
  if (!query) return true;
  const values = [post.text];
  for (const answer of post.answers || []) {
    values.push(answer.text);
    for (const reply of answer.replies || []) values.push(reply.text);
  }
  return values.some((value) => value?.toLocaleLowerCase('de').includes(query));
}

function makeAuthor(author, anonymousLabel = 'Anonym') {
  const info = document.createElement('span');
  info.className = 'author-info';
  const name = document.createElement('span');
  name.className = 'author-tag tag';
  name.textContent = author?.username ? `@${author.username}` : anonymousLabel;
  info.appendChild(name);

  if (author?.rank) {
    const rank = document.createElement('span');
    rank.className = 'author-rank';
    rank.textContent = author.rank;
    info.appendChild(rank);
  }
  if (author?.gender === 'pixelated') {
    const pixelated = document.createElement('span');
    pixelated.className = 'gender-pixelated';
    pixelated.setAttribute('aria-label', 'Geschlecht verpixelt');
    pixelated.textContent = '▦ ▦ ▦';
    info.appendChild(pixelated);
  } else if (author?.gender) {
    const gender = document.createElement('span');
    gender.className = 'author-gender';
    gender.textContent = author.gender;
    info.appendChild(gender);
  }
  return info;
}

function makePostActions(contentType, contentId, canDelete) {
  const actions = document.createElement('div');
  actions.className = 'post-actions';
  const reportButton = document.createElement('button');
  reportButton.className = 'post-action-button';
  reportButton.type = 'button';
  reportButton.textContent = 'Melden';
  reportButton.addEventListener('click', () => {
    if (!currentAccount) {
      showNotice('Zum Melden musst du angemeldet sein.');
      setAuthTab('login');
      accountDialog.showModal();
      return;
    }
    pendingReport = { contentType, contentId };
    document.getElementById('report-error').hidden = true;
    document.getElementById('report-form').reset();
    document.getElementById('report-dialog').showModal();
  });
  actions.appendChild(reportButton);

  if (canDelete) {
    const deleteButton = document.createElement('button');
    deleteButton.className = 'post-action-button delete-post-button';
    deleteButton.type = 'button';
    deleteButton.textContent = 'Löschen';
    deleteButton.addEventListener('click', () => {
      pendingDelete = { contentType, contentId };
      document.getElementById('delete-dialog').showModal();
    });
    actions.appendChild(deleteButton);
  }
  return actions;
}

function makeIdentityChoice(className = 'identity-choice') {
  const wrapper = document.createElement('div');
  wrapper.className = className;
  wrapper.hidden = !currentAccount;

  const nameLabel = document.createElement('label');
  nameLabel.className = 'check-choice';
  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  const nameText = document.createTextNode(' Username zeigen');
  nameLabel.append(checkbox, nameText);

  const rankLabel = document.createElement('label');
  rankLabel.className = 'check-choice';
  const rankCheckbox = document.createElement('input');
  rankCheckbox.type = 'checkbox';
  rankLabel.append(rankCheckbox, document.createTextNode(' Rang zeigen'));

  const genderLabel = document.createElement('label');
  genderLabel.className = 'gender-choice';
  genderLabel.append(document.createTextNode('Geschlecht'));
  const select = document.createElement('select');
  select.setAttribute('aria-label', 'Geschlecht bei diesem Beitrag');
  for (const [value, label] of [
    ['hidden', 'Nicht anzeigen'],
    ['pixelated', 'Verpixelt anzeigen'],
    ['public', 'Anzeigen'],
  ]) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    select.appendChild(option);
  }
  genderLabel.appendChild(select);
  wrapper.append(nameLabel, rankLabel, genderLabel);
  return { wrapper, checkbox, rankCheckbox, select };
}

async function loadMemes() {
  const feed = document.getElementById('memes-feed');
  try {
    const memes = await requestJson('/api/memes');
    feed.replaceChildren();
    if (!memes.length) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.innerHTML = '<strong>Noch keine Memes</strong><span>Mach den Anfang mit einem Schul-Meme.</span>';
      feed.appendChild(empty);
      return;
    }
    memes.forEach((meme) => feed.appendChild(renderMeme(meme)));
  } catch (error) {
    showNotice(error.message, true);
  }
}

function renderMeme(meme) {
  const card = document.createElement('article');
  card.className = 'meme-card';
  const header = document.createElement('header');
  header.className = 'meme-meta';
  header.append(makeAuthor(meme.author));
  const date = document.createElement('time');
  date.dateTime = meme.createdAt;
  date.textContent = formatTime(meme.createdAt);
    header.append(date, makePostActions('meme', meme.id, meme.canDelete));

  const image = document.createElement('img');
  image.className = 'meme-image';
  image.src = meme.imageUrl;
  image.alt = meme.caption || 'Schul-Meme';
  image.loading = 'lazy';
  card.append(header, image);
  if (meme.caption) {
    const caption = document.createElement('p');
    caption.className = 'meme-caption';
    caption.textContent = meme.caption;
    card.appendChild(caption);
  }

  const reactions = document.createElement('div');
  reactions.className = 'meme-reactions';
  for (const [reaction, label, count] of [
    ['like', 'Gefällt mir', meme.likes],
    ['dislike', 'Gefällt mir nicht', meme.dislikes],
  ]) {
    const button = document.createElement('button');
    button.className = `reaction-button ${meme.userReaction === reaction ? 'is-selected' : ''}`;
    button.type = 'button';
    button.setAttribute('aria-pressed', String(meme.userReaction === reaction));
    button.textContent = `${label} · ${count}`;
    button.addEventListener('click', async () => {
      if (!currentAccount) {
        showNotice('Zum Bewerten musst du angemeldet sein.');
        setAuthTab('login');
        accountDialog.showModal();
        return;
      }
      try {
        const result = await requestJson(`/api/memes/${meme.id}/votes`, {
          method: 'POST',
          body: JSON.stringify({ reaction: meme.userReaction === reaction ? 'remove' : reaction }),
        });
        if (result.deleted) showNotice('Dieses Meme wurde wegen zu vieler Dislikes entfernt.');
        await loadMemes();
      } catch (error) {
        showNotice(error.message, true);
      }
    });
    reactions.appendChild(button);
  }
  card.appendChild(reactions);

  const commentsSection = document.createElement('section');
  commentsSection.className = 'meme-comments';
  const commentsHeading = document.createElement('h3');
  commentsHeading.textContent = `Kommentare (${meme.comments.length})`;
  commentsSection.appendChild(commentsHeading);
  const commentsList = document.createElement('div');
  commentsList.className = 'meme-comment-list';
  meme.comments.forEach((comment) => {
    const item = document.createElement('div');
    item.className = 'meme-comment';
    item.appendChild(makeAuthor(comment.author));
    const commentText = document.createElement('p');
    commentText.textContent = comment.text;
    item.appendChild(commentText);
    commentsList.appendChild(item);
  });
  commentsSection.appendChild(commentsList);

  const commentForm = document.createElement('form');
  commentForm.className = 'meme-comment-form';
  const commentInput = document.createElement('input');
  commentInput.type = 'text';
  commentInput.maxLength = 500;
  commentInput.placeholder = 'Kommentar schreiben …';
  commentInput.required = true;
  const identity = makeIdentityChoice('identity-choice comment-identity-choice');
  identity.wrapper.hidden = !currentAccount;
  const submit = document.createElement('button');
  submit.className = 'button-secondary';
  submit.type = 'submit';
  submit.textContent = 'Kommentieren';
  commentForm.append(commentInput, identity.wrapper, submit);
  commentForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    try {
      await requestJson(`/api/memes/${meme.id}/comments`, {
        method: 'POST',
        body: JSON.stringify({
          text: commentInput.value,
          displayUsername: identity.checkbox.checked,
          displayRank: identity.rankCheckbox.checked,
          genderVisibility: identity.select.value,
        }),
      });
      await loadMemes();
    } catch (error) {
      showNotice(error.message, true);
    }
  });
  commentsSection.appendChild(commentForm);
  card.appendChild(commentsSection);
  return card;
}

async function loadPolls() {
  const feed = document.getElementById('polls-feed');
  try {
    const polls = await requestJson('/api/polls');
    feed.replaceChildren();
    if (!polls.length) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.innerHTML = '<strong>Noch keine Umfragen</strong><span>Starte die erste Abstimmung an der Schule.</span>';
      feed.appendChild(empty);
      return;
    }
    polls.forEach((poll) => feed.appendChild(renderPoll(poll)));
  } catch (error) {
    showNotice(error.message, true);
  }
}

function renderPoll(poll) {
  const card = document.createElement('article');
  card.className = 'poll-card';
  const header = document.createElement('header');
  header.className = 'poll-meta';
  header.appendChild(makeAuthor(poll.author));
  const date = document.createElement('time');
  date.dateTime = poll.createdAt;
  date.textContent = formatTime(poll.createdAt);
    header.append(date, makePostActions('poll', poll.id, poll.canDelete));
  const title = document.createElement('h3');
  title.textContent = poll.title;
  card.append(header, title);

  const options = document.createElement('div');
  options.className = 'poll-option-list';
  if (poll.hasVoted) {
    for (const option of poll.options) {
      const row = document.createElement('div');
      row.className = 'poll-result';
      const labels = document.createElement('div');
      labels.className = 'poll-result-labels';
      const text = document.createElement('span');
      text.textContent = option.text;
      const percent = document.createElement('strong');
      percent.textContent = `${option.percentage}%`;
      labels.append(text, percent);
      const track = document.createElement('div');
      track.className = 'poll-result-track';
      const bar = document.createElement('span');
      bar.style.width = `${option.percentage}%`;
      track.appendChild(bar);
      const votes = document.createElement('small');
      votes.textContent = `${option.votes} ${option.votes === 1 ? 'Stimme' : 'Stimmen'}`;
      row.append(labels, track, votes);
      options.appendChild(row);
    }
    const total = document.createElement('p');
    total.className = 'poll-total';
    total.textContent = `${poll.results.totalVotes} abgegebene Stimmen`;
    options.appendChild(total);
  } else {
    const form = document.createElement('form');
    form.className = 'poll-vote-form';
    poll.options.forEach((option) => {
      const label = document.createElement('label');
      label.className = 'poll-choice';
      const radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = `poll-${poll.id}`;
      radio.value = option.id;
      radio.required = true;
      const text = document.createElement('span');
      text.textContent = option.text;
      label.append(radio, text);
      form.appendChild(label);
    });
    const voteButton = document.createElement('button');
    voteButton.className = 'button-primary';
    voteButton.type = 'submit';
    voteButton.textContent = 'Abstimmen';
    form.appendChild(voteButton);
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!currentAccount) {
        showNotice('Zum Abstimmen musst du angemeldet sein.');
        setAuthTab('login');
        accountDialog.showModal();
        return;
      }
      const selected = form.querySelector('input:checked');
      try {
        await requestJson(`/api/polls/${poll.id}/votes`, {
          method: 'POST',
          body: JSON.stringify({ optionId: selected.value }),
        });
        showNotice('Deine Stimme wurde gezählt.');
        await loadPolls();
      } catch (error) {
        showNotice(error.message, true);
      }
    });
    options.appendChild(form);
    const hiddenResults = document.createElement('p');
    hiddenResults.className = 'poll-privacy-hint';
    hiddenResults.textContent = 'Stimme ab, um die bisherige Verteilung zu sehen.';
    options.appendChild(hiddenResults);
  }
  card.appendChild(options);
  return card;
}

function createPollOption(value = '') {
  const row = document.createElement('div');
  row.className = 'poll-option-row';
  const input = document.createElement('input');
  input.name = 'option';
  input.maxLength = 100;
  input.placeholder = `Möglichkeit ${document.querySelectorAll('#poll-options input').length + 1}`;
  input.value = value;
  input.required = true;
  const remove = document.createElement('button');
  remove.className = 'button-quiet remove-option';
  remove.type = 'button';
  remove.setAttribute('aria-label', 'Antwortmöglichkeit entfernen');
  remove.textContent = '×';
  remove.addEventListener('click', () => {
    row.remove();
    updatePollOptions();
  });
  row.append(input, remove);
  document.getElementById('poll-options').appendChild(row);
  updatePollOptions();
}

function updatePollOptions() {
  const rows = [...document.querySelectorAll('#poll-options .poll-option-row')];
  document.getElementById('add-poll-option').disabled = rows.length >= 6;
  rows.forEach((row, index) => {
    row.querySelector('input').placeholder = `Möglichkeit ${index + 1}`;
    row.querySelector('.remove-option').disabled = rows.length <= 2;
  });
}

function initializePollOptions() {
  const initialOptions = [...document.querySelectorAll('#poll-options input')].map((input) => input.value);
  document.getElementById('poll-options').replaceChildren();
  initialOptions.forEach((value) => createPollOption(value));
}

function appendAnswerForm(parent, question, answer = null) {
  const form = document.createElement('form');
  form.className = answer ? 'reply-form' : 'answer-form';
  const textarea = document.createElement('textarea');
  textarea.rows = answer ? 2 : 2;
  textarea.maxLength = 500;
  textarea.placeholder = answer ? 'Schreib eine Antwort auf diesen Kommentar …' : 'Was meinst du dazu?';
  textarea.required = true;
  const controls = document.createElement('div');
  controls.className = 'answer-controls';
  const identity = makeIdentityChoice('identity-choice answer-identity-choice');
  const anonymousMode = ['confession', 'worry'].includes(question.type);
  identity.wrapper.hidden = !currentAccount || anonymousMode;
  const button = document.createElement('button');
  button.className = 'button-secondary';
  button.type = 'submit';
  button.textContent = answer ? 'Antwort senden' : 'Antworten ↗';
  controls.append(identity.wrapper, button);
  form.append(textarea, controls);

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const text = textarea.value.trim();
    if (!text) return;
    const endpoint = answer
      ? `/api/questions/${question.id}/answers/${answer.id}/replies`
      : `/api/questions/${question.id}/answers`;
    try {
      await requestJson(endpoint, {
        method: 'POST',
        body: JSON.stringify({
          text,
          displayUsername: !anonymousMode && identity.checkbox.checked,
          displayRank: !anonymousMode && identity.rankCheckbox.checked,
          genderVisibility: !anonymousMode ? identity.select.value : 'hidden',
        }),
      });
      showNotice(answer ? 'Dein Beitrag zur Diskussion ist da.' : 'Deine Antwort wurde veröffentlicht.');
      await loadQuestions();
    } catch (error) {
      showNotice(error.message, true);
    }
  });
  parent.appendChild(form);
}

function renderAnswer(question, answer) {
  const thread = document.createElement('article');
  thread.className = 'thread-entry';
  const comment = document.createElement('div');
  comment.className = 'answer-item';
  comment.appendChild(makeAuthor(answer.author));
  const text = document.createElement('p');
  text.textContent = answer.text;
  const replies = Array.isArray(answer.replies) ? answer.replies : [];
  const replyButton = document.createElement('button');
  replyButton.className = 'reply-toggle';
  replyButton.type = 'button';
  replyButton.textContent = `Auf Antwort eingehen · ${replies.length}`;
  comment.append(text, replyButton);
  thread.appendChild(comment);

  const replyList = document.createElement('div');
  replyList.className = 'reply-list';
  for (const reply of sortItems(replies)) {
    const replyItem = document.createElement('div');
    replyItem.className = 'reply-item';
    replyItem.appendChild(makeAuthor(reply.author));
    const replyText = document.createElement('p');
    replyText.textContent = reply.text;
    replyItem.appendChild(replyText);
    replyList.appendChild(replyItem);
  }
  thread.appendChild(replyList);

  const replyFormHost = document.createElement('div');
  replyFormHost.className = 'reply-form-host';
  replyFormHost.hidden = true;
  appendAnswerForm(replyFormHost, question, answer);
  replyButton.addEventListener('click', () => {
    replyFormHost.hidden = !replyFormHost.hidden;
    if (!replyFormHost.hidden) replyFormHost.querySelector('textarea').focus();
  });
  thread.appendChild(replyFormHost);
  return thread;
}

function renderPost(post) {
  const card = questionTemplate.content.firstElementChild.cloneNode(true);
  const isConfession = post.type === 'confession';
  const isWorry = post.type === 'worry';
  const isWishlist = post.type === 'wishlist';
  const isAnonymousMode = isConfession || isWorry;
  card.classList.toggle('confession-card', isAnonymousMode);
  card.classList.toggle('wishlist-card', isWishlist);
  card.querySelector('.post-kind').textContent = isConfession
    ? 'Beichte · 100% anonym'
    : isWorry ? 'Sorgenfresser · anonym' : isWishlist ? 'Wunschliste' : 'Frage';
  card.querySelector('.author-info').replaceWith(makeAuthor(post.author, isConfession ? '100% anonym' : 'Anonym'));
  const time = card.querySelector('.time');
  time.dateTime = post.createdAt;
  time.textContent = formatTime(post.createdAt);
    card.querySelector('.question-head').appendChild(makePostActions('question', post.id, post.canDelete));
  card.querySelector('.question-text').textContent = post.text;

  const answers = Array.isArray(post.answers) ? sortItems(post.answers) : [];
  card.querySelector('.answer-count').textContent = `(${answers.length})`;
  const answerContainer = card.querySelector('.answers');
  if (answers.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'no-answers';
    empty.textContent = 'Noch keine Antworten. Du kannst die erste geben.';
    answerContainer.appendChild(empty);
  } else {
    for (const answer of answers) answerContainer.appendChild(renderAnswer(post, answer));
  }
  appendAnswerForm(card.querySelector('.answer-form').parentElement, post);
  card.querySelector('.answer-form').remove();
  return card;
}

function renderQuestions() {
  const modePosts = allPosts.filter((post) => (post.type || 'question') === activeMode);
  const questions = activeMode === 'question' ? modePosts : [];
  const answeredCount = questions.filter((post) => post.answers?.length > 0).length;
  document.getElementById('count-all').textContent = String(questions.length);
  document.getElementById('count-open').textContent = String(questions.length - answeredCount);
  document.getElementById('count-answered').textContent = String(answeredCount);

  const query = searchInput.value.trim().toLocaleLowerCase('de');
  let visiblePosts = modePosts.filter((post) => {
    const answered = (post.answers || []).length > 0;
    const statusMatches = activeMode !== 'question' || activeStatus === 'all'
      || (activeStatus === 'answered' ? answered : !answered);
    return statusMatches && postMatchesSearch(post, query);
  });
  if (activeSort === 'popular') {
    visiblePosts.sort((left, right) => popularity(right) - popularity(left)
      || new Date(right.createdAt) - new Date(left.createdAt));
  } else {
    visiblePosts.sort((left, right) => {
      const difference = new Date(right.createdAt) - new Date(left.createdAt);
      return activeSort === 'oldest' ? -difference : difference;
    });
  }

  questionCount.textContent = String(visiblePosts.length);
  questionsContainer.replaceChildren();
  if (activeMode !== 'question') {
    document.getElementById('feed-heading').textContent = activeMode === 'confession'
      ? 'Beichten aus der Community'
      : activeMode === 'worry' ? 'Geteilte Sorgen'
        : activeMode === 'wishlist' ? 'Wünsche an die Schule' : 'Geteilte Sorgen';
    document.querySelector('.status-filters').hidden = true;
  } else {
    document.getElementById('feed-heading').textContent = 'Fragen im Raum';
    document.querySelector('.status-filters').hidden = false;
  }
  if (visiblePosts.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    const strong = document.createElement('strong');
    strong.textContent = query ? 'Nichts gefunden'
      : activeMode === 'confession' ? 'Der Beichtstuhl ist noch leer'
        : activeMode === 'worry' ? 'Noch keine Sorgen geteilt'
          : activeMode === 'wishlist' ? 'Noch keine Wünsche eingetragen' : 'Noch nichts gefragt';
    const message = document.createElement('span');
    message.textContent = query ? 'Versuch es mit einem anderen Suchbegriff.'
      : activeMode === 'confession' ? 'Deine Beichte bleibt zu 100% anonym.'
        : activeMode === 'worry' ? 'Hier kannst du alles anonym teilen. Das Bach hält zusammen.'
          : activeMode === 'wishlist' ? 'Teile eine Idee mit der SMV und der Schulleitung.'
            : 'Mach den Anfang. Deine Frage kann anonym bleiben.';
    empty.append(strong, message);
    questionsContainer.appendChild(empty);
  } else {
    visiblePosts.forEach((post) => questionsContainer.appendChild(renderPost(post)));
  }
}

function setMode(mode) {
  activeMode = mode;
  document.querySelectorAll('.mode-button').forEach((button) => {
    const active = button.dataset.mode === mode;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  const confession = mode === 'confession';
  const worry = mode === 'worry';
  const wishlist = mode === 'wishlist';
  const memes = mode === 'memes';
  const polls = mode === 'polls';
  const anonymousMode = confession || worry;
  document.querySelector('.home-columns').hidden = memes || polls;
  document.getElementById('memes-panel').hidden = !memes;
  document.getElementById('polls-panel').hidden = !polls;
  document.querySelector('.home-content').classList.toggle('wishlist-mode', wishlist);
  document.getElementById('composer-kicker').textContent = confession
    ? 'Ein geschützter Raum' : worry ? 'Du musst damit nicht allein sein'
      : wishlist ? 'Für ein besseres Bach' : 'Deine Stimme zählt';
  document.getElementById('composer-title').textContent = confession
    ? 'Bach Beichtstuhl' : worry ? 'Sorgenfresser' : wishlist ? 'Wunschliste' : 'Hau hier deine Fragen raus !';
  document.getElementById('wishlist-description').hidden = !wishlist;
  document.getElementById('confession-guarantee').textContent = confession
    ? 'Bach Beichtstuhl · 100% anonym' : 'Sorgenfresser · anonym';
  document.getElementById('confession-guarantee').hidden = !anonymousMode;
  document.getElementById('post-button').innerHTML = confession
    ? 'Beichte teilen <span aria-hidden="true">↗</span>'
    : worry ? 'Sorge teilen <span aria-hidden="true">↗</span>'
      : wishlist ? 'Wunsch eintragen <span aria-hidden="true">↗</span>'
        : 'Frage posten <span aria-hidden="true">↗</span>';
  questionInput.placeholder = worry
    ? 'Egal ob Prüfungen, Lehrer oder andere Ungewissheiten, hier kannst du alles anonym teilen :-) Das Bach hält zusammen.'
    : confession ? 'z.b. Ich hab mal bei Frau Pagel die komplette Arbeit mit Chat Gpt gemacht...'
      : wishlist ? 'Was würdest du an unserer Schule gerne verändern?'
        : 'Hier kannst du ALLES fragen, die Bach Community hilft dir !';
  document.getElementById('guest-hint').textContent = confession
    ? 'Deine Beichte und alle Antworten darauf bleiben zu 100% anonym.'
    : worry ? 'Deine Sorgen und alle Antworten darauf bleiben anonym.'
      : wishlist ? 'Dein Wunsch wird hier mit der Community geteilt.'
        : 'Als Gast postest du anonym. Melde dich an, wenn dein Username erscheinen soll.';
  document.getElementById('guest-hint').hidden = Boolean(currentAccount) && !anonymousMode;
  updateAccountControls();
  if (memes) loadMemes();
  else if (polls) loadPolls();
  else renderQuestions();
}

questionInput.addEventListener('input', () => {
  document.getElementById('question-length').textContent = String(questionInput.value.length);
});

questionForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const text = questionInput.value.trim();
  if (!text) return;
  const anonymousMode = ['confession', 'worry'].includes(activeMode);
  const identity = document.getElementById('question-identity');
  const rank = document.getElementById('question-rank');
  const gender = document.getElementById('question-gender');
  try {
    await requestJson('/api/questions', {
      method: 'POST',
      body: JSON.stringify({
        text,
        type: activeMode,
        displayUsername: !anonymousMode && identity.checked,
        displayRank: !anonymousMode && rank.checked,
        genderVisibility: !anonymousMode ? gender.value : 'hidden',
      }),
    });
    questionForm.reset();
    gender.value = 'hidden';
    document.getElementById('question-length').textContent = '0';
    showNotice(activeMode === 'confession' ? 'Deine Beichte wurde 100% anonym veröffentlicht.'
      : activeMode === 'worry' ? 'Deine Sorge wurde anonym geteilt.'
        : activeMode === 'wishlist' ? 'Dein Wunsch steht auf der Liste.' : 'Deine Frage ist jetzt im Raum.');
    await loadQuestions();
    questionInput.focus();
  } catch (error) {
    showNotice(error.message, true);
  }
});

document.querySelectorAll('.mode-button').forEach((button) => {
  button.addEventListener('click', () => setMode(button.dataset.mode));
});

document.querySelectorAll('.status-button').forEach((button) => {
  button.addEventListener('click', () => {
    activeStatus = button.dataset.status;
    document.querySelectorAll('.status-button').forEach((tab) => {
      const selected = tab === button;
      tab.classList.toggle('is-active', selected);
      tab.setAttribute('aria-selected', String(selected));
    });
    renderQuestions();
  });
});

searchInput.addEventListener('input', renderQuestions);
document.getElementById('sort-select').addEventListener('change', (event) => {
  activeSort = event.target.value;
  renderQuestions();
});

const memeForm = document.getElementById('meme-form');
const memeImageInput = document.getElementById('meme-image');
let memePreviewUrl = null;

memeImageInput.addEventListener('change', () => {
  const file = memeImageInput.files[0];
  const preview = document.getElementById('meme-preview');
  if (memePreviewUrl) URL.revokeObjectURL(memePreviewUrl);
  if (!file) {
    preview.hidden = true;
    return;
  }
  if (file.type !== 'image/jpeg' || file.size > 8 * 1024 * 1024) {
    showNotice('Bitte nutze ein JPEG-Bild mit höchstens 8 MB.', true);
    memeImageInput.value = '';
    preview.hidden = true;
    return;
  }
  memePreviewUrl = URL.createObjectURL(file);
  preview.src = memePreviewUrl;
  preview.hidden = false;
});

memeForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const file = memeImageInput.files[0];
  if (!file) return;
  const formData = new FormData(memeForm);
  formData.set('displayUsername', String(document.getElementById('meme-display-username').checked));
  formData.set('displayRank', String(document.getElementById('meme-display-rank').checked));
  formData.set('genderVisibility', document.getElementById('meme-gender-visibility').value);
  try {
    await requestJson('/api/memes', { method: 'POST', body: formData });
    memeForm.reset();
    document.getElementById('meme-preview').hidden = true;
    if (memePreviewUrl) URL.revokeObjectURL(memePreviewUrl);
    memePreviewUrl = null;
    showNotice('Dein Meme wurde gepostet.');
    await loadMemes();
  } catch (error) {
    showNotice(error.message, true);
  }
});

initializePollOptions();
document.getElementById('add-poll-option').addEventListener('click', () => {
  if (document.querySelectorAll('#poll-options .poll-option-row').length < 6) createPollOption();
});

document.getElementById('create-poll-button').addEventListener('click', () => {
  document.getElementById('poll-error').hidden = true;
  document.getElementById('poll-dialog').showModal();
});
document.getElementById('close-poll-dialog').addEventListener('click', () => {
  document.getElementById('poll-dialog').close();
});
document.getElementById('poll-dialog').addEventListener('click', (event) => {
  if (event.target === event.currentTarget) event.currentTarget.close();
});

document.getElementById('poll-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  const payload = {
    title: formData.get('title'),
    options: formData.getAll('option'),
    displayUsername: document.getElementById('poll-display-username').checked,
    displayRank: document.getElementById('poll-display-rank').checked,
    genderVisibility: document.getElementById('poll-gender-visibility').value,
  };
  try {
    await requestJson('/api/polls', { method: 'POST', body: JSON.stringify(payload) });
    document.getElementById('poll-dialog').close();
    form.reset();
    initializePollOptions();
    showNotice('Deine Umfrage ist veröffentlicht.');
    await loadPolls();
  } catch (error) {
    const pollError = document.getElementById('poll-error');
    pollError.textContent = error.message;
    pollError.hidden = false;
  }
});

document.getElementById('close-report-dialog').addEventListener('click', () => {
  document.getElementById('report-dialog').close();
});
document.getElementById('report-dialog').addEventListener('click', (event) => {
  if (event.target === event.currentTarget) event.currentTarget.close();
});
document.getElementById('report-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!pendingReport) return;
  try {
    await requestJson('/api/reports', {
      method: 'POST',
      body: JSON.stringify({ ...pendingReport, reason: document.getElementById('report-reason').value }),
    });
    document.getElementById('report-dialog').close();
    showNotice('Danke. Deine Meldung wurde gespeichert.');
    pendingReport = null;
  } catch (error) {
    const reportError = document.getElementById('report-error');
    reportError.textContent = error.message;
    reportError.hidden = false;
  }
});

function closeDeleteDialog() {
  document.getElementById('delete-dialog').close();
  pendingDelete = null;
}

document.getElementById('close-delete-dialog').addEventListener('click', closeDeleteDialog);
document.getElementById('cancel-delete').addEventListener('click', closeDeleteDialog);
document.getElementById('delete-dialog').addEventListener('click', (event) => {
  if (event.target === event.currentTarget) closeDeleteDialog();
});
document.getElementById('confirm-delete').addEventListener('click', async () => {
  if (!pendingDelete) return;
  try {
    await requestJson(`/api/${pendingDelete.contentType}s/${pendingDelete.contentId}`, { method: 'DELETE' });
    closeDeleteDialog();
    showNotice('Dein Beitrag und die zugehörigen Inhalte wurden gelöscht.');
    await reloadActiveMode();
  } catch (error) {
    showNotice(error.message, true);
  }
});

function setAuthTab(tabName) {
  const isLogin = tabName === 'login';
  document.getElementById('login-form').hidden = !isLogin;
  document.getElementById('register-form').hidden = isLogin;
  document.getElementById('dialog-title').textContent = isLogin ? 'Bei Bach-Gossip anmelden' : 'Konto erstellen';
  authError.hidden = true;
  document.querySelectorAll('.auth-tab').forEach((tab) => {
    const selected = tab.dataset.authTab === tabName;
    tab.classList.toggle('is-active', selected);
    tab.setAttribute('aria-selected', String(selected));
  });
}

document.querySelectorAll('.auth-tab').forEach((tab) => {
  tab.addEventListener('click', () => setAuthTab(tab.dataset.authTab));
});

accountButton.addEventListener('click', () => {
  setAuthTab('login');
  accountDialog.showModal();
});

document.getElementById('close-dialog').addEventListener('click', () => accountDialog.close());
accountDialog.addEventListener('click', (event) => {
  if (event.target === accountDialog) accountDialog.close();
});

for (const formId of ['login-form', 'register-form']) {
  document.getElementById(formId).addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const payload = Object.fromEntries(new FormData(form).entries());
    const endpoint = formId === 'login-form' ? '/api/login' : '/api/register';
    try {
      currentAccount = await requestJson(endpoint, { method: 'POST', body: JSON.stringify(payload) });
      accountDialog.close();
      form.reset();
      updateAccountControls();
      showNotice(`Willkommen bei Bach-Gossip, @${currentAccount.username}.`);
      await reloadActiveMode();
    } catch (error) {
      authError.textContent = error.message;
      authError.hidden = false;
    }
  });
}

logoutButton.addEventListener('click', async () => {
  try {
    await requestJson('/api/logout', { method: 'POST' });
    currentAccount = null;
    updateAccountControls();
    showNotice('Du bist abgemeldet. Deine Beiträge bleiben anonym sichtbar.');
    await reloadActiveMode();
  } catch (error) {
    showNotice(error.message, true);
  }
});

async function initialize() {
  try {
    currentAccount = await requestJson('/api/me');
  } catch {
    currentAccount = null;
  }
  updateAccountControls();
  await loadQuestions();
}

initialize();
